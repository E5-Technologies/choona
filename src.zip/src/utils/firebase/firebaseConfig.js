// eslint-disable-next-line no-undef
export default (firebaseConfig = {
  apiKey: 'AIzaSyDTjMcpsLByuiKnOcTzE22iQZzvvHYwTjc',
  authDomain: 'choona-8db54.firebaseapp.com',
  databaseURL: 'https://choona-8db54.firebaseio.com',
  projectId: 'choona-8db54',
  storageBucket: 'choona-8db54.appspot.com',
  messagingSenderId: '257140745990',
  clientId:
    '257140745990-b00tir0rv6cd3gmb934cqql5e6i6eagv.apps.googleusercontent.com',
});
