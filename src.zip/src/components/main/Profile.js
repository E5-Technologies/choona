import React, { useEffect, useState } from 'react';
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  FlatList,
  Image,
  ImageBackground,
  Modal,
  Dimensions,
} from 'react-native';
import normalise from '../../utils/helpers/Dimens';
import Colors from '../../assests/Colors';
import ImagePath from '../../assests/ImagePath';
import _ from 'lodash';
import StatusBar from '../../utils/MyStatusBar';
import { connect } from 'react-redux';
import constants from '../../utils/helpers/constants';
import { WebView } from 'react-native-webview';
import {
  USER_PROFILE_REQUEST,
  USER_PROFILE_SUCCESS,
  USER_PROFILE_FAILURE,
  COUNTRY_CODE_REQUEST,
  COUNTRY_CODE_SUCCESS,
  COUNTRY_CODE_FAILURE,
} from '../../action/TypeConstants';
import {
  getProfileRequest,
  userLogoutReq,
  getCountryCodeRequest,
} from '../../action/UserAction';
import toast from '../../utils/helpers/ShowErrorAlert';
import Loader from '../../widgets/AuthLoader';
import isInternetConnected from '../../utils/helpers/NetInfo';

import useSWR from 'swr';
import axios from 'axios';

let status = '';

const postsUrl = constants.BASE_URL + '/user/posts';

function Profile(props) {
  const [modalVisible, setModalVisible] = useState(false);
  const [modalPrivacy, setModalPrivacy] = useState(false);
  const [modaltandcs, setModaltandcs] = useState(false);
  const [flag, setFlag] = useState('');
  const [activity, setActivity] = useState(props.route.params.fromAct);
  const[newarr,setnewarr]=useState([]);

  const getPosts = async pageId => {
    const response = await axios.get(`${postsUrl}?page=${pageId}`, {
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        'x-access-token': props.header.token,
      },
    });
  
    // console.log("rs" + JSON.stringify(response.data))
    return await response.data.data;
  };

  const [pageId, setPageId] = useState(1);
  const key = `${postsUrl}?page=${pageId}`;
  const { data: posts, mutate } = useSWR(key, () => getPosts(pageId));

  // const[profilePosts,setProfilePosts] = useState(posts ? posts.data : []);
  const[profilePosts,setProfilePosts] = useState([]);


  const onEndReached=async()=>{
  
    setPageId(pageId+1)
   const response = await axios.get(`${postsUrl}?page=${pageId+1}`, {
     headers: {
       Accept: 'application/json',
       'Content-Type': 'application/json',
       'x-access-token': props.header.token,
     },
   });
  setProfilePosts([...profilePosts,...response.data.data])
  
   } 

  useEffect(() => {
    // const unsuscribe = props.navigation.addListener('focus', payload => {
      isInternetConnected()
        .then(async() => {
          props.getProfileReq();
          props.getCountryCode();
            
   const response = await axios.get(`${postsUrl}?page=${1}`, {
     headers: {
       Accept: 'application/json',
       'Content-Type': 'application/json',
       'x-access-token': props.header.token,
     },
   });
 profilePosts.length===0 ?
  setProfilePosts(response.data.data):null
        })
        .catch(() => {
          toast('Error', 'Please Connect To Internet');
        });
    // });

    // return () => {
    //   unsuscribe();
    // };
  },[]);

  if (status === '' || props.status !== status) {
    switch (props.status) {
      case USER_PROFILE_REQUEST:
        status = props.status;
        break;

      case USER_PROFILE_SUCCESS:
        status = props.status;
        if (activity) {
          // console.log('get index');
          getIndex();
        }
        break;

      case USER_PROFILE_FAILURE:
        status = props.status;
        toast('Oops', 'Something Went Wrong, Please Try Again');
        break;

      case COUNTRY_CODE_REQUEST:
        status = props.status;
        break;

      case COUNTRY_CODE_SUCCESS:
        status = props.status;
        getLocationFlag(props.userProfileResp.location);
        break;

      case COUNTRY_CODE_FAILURE:
        status = props.status;
        toast('Oops', 'Something Went Wrong, Please Try Again');
        break;
    }
  }

  function getLocationFlag(country) {
    let index = props.countryCode.findIndex(obj => obj.name === country);
    if (index !== -1) {
      setFlag(props.countryCode[index].flag);
    }
  }

  function getIndex() {
    let index = profilePosts.findIndex(
      obj => obj._id === props.route.params.postId,
    );
    if (index !== -1) {
      props.navigation.replace('PostListForUser', {
        profile_name: props.userProfileResp.full_name,
        posts: profilePosts,
        index: index,
      });
    } else {
      toast('Oops', 'Post not found');
    }
  }





  function renderProfileData(data) {
    let array=[]
    array.push(data.item)
    return (
      <TouchableOpacity
        onPress={() => {
            props.navigation.navigate('PostListForUser', {
            profile_name: props.userProfileResp.full_name,
            posts: array,
            index: '0',
          });
        }}
        style={{
          margin: normalise(4),
          marginBottom:
            data.index === profilePosts.length - 1
              ? normalise(30)
              : normalise(5),
        }}>
        <Image
          source={{
            uri:
              props.userProfileResp.register_type === 'spotify'
                ? data.item.song_image
                : data.item.song_image.replace(
                    '100x100bb.jpg',
                    '500x500bb.jpg',
                  ),
          }}
          style={{
            width: Dimensions.get('window').width / 2.1,
            height: Dimensions.get('window').height * 0.22,
          }}
          resizeMode="cover"
        />
      </TouchableOpacity>
    );
  }

  const renderModal = () => {
    return (
      <Modal
        animationType="fade"
        transparent={true}
        visible={modalVisible}
        presentationStyle={'pageSheet'}
        onRequestClose={() => {}}>
        <ImageBackground
          source={ImagePath.page_gradient}
          style={styles.centeredView}>
          <View style={styles.modalView}>
            <TouchableOpacity 
            onPress={()=>{setModalPrivacy(true)}}
            >
              <Text
                style={{
                  color: Colors.white,
                  fontSize: normalise(13),
                  fontFamily: 'ProximaNova-Semibold',
                }}>
                Privacy Policy
              </Text>
            </TouchableOpacity>

            <TouchableOpacity style={{ marginTop: normalise(18) }}>
              <Text
                style={{
                  color: Colors.white,
                  fontSize: normalise(13),
                  fontFamily: 'ProximaNova-Semibold',
                }}>
                Terms of Usage
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity style={{ marginTop: normalise(18) }}
            onPress={()=>{setModaltandcs(true)}}
            >
              <Text
                style={{
                  color: Colors.white,
                  fontSize: normalise(13),
                  fontFamily: 'ProximaNova-Semibold',
                }}>
                Terms & Conditions
              </Text>
            </TouchableOpacity>


            {/* <TouchableOpacity
                            style={{ marginTop: normalise(18) }}>
                            <Text style={{
                                color: Colors.white,
                                fontSize: normalise(13),
                                fontFamily: 'ProximaNova-Semibold',
                            }}>Change Password</Text>
                        </TouchableOpacity> */}

            <TouchableOpacity
              style={{ marginTop: normalise(18) }}
              onPress={() => {
                setModalVisible(!modalVisible), props.logoutReq();
              }}>
              <Text
                style={{
                
                  color: Colors.red,
                  fontSize: normalise(13),
                  fontFamily: 'ProximaNova-Semibold',
                }}>
                Logout
              </Text>
            </TouchableOpacity>
            <Text
                style={{
                  marginTop: normalise(18),
                  color: Colors.grey,
                  fontSize: normalise(13),
                  fontFamily: 'ProximaNova-Semibold',
                }}>
                Version <Text style={{fontSize:normalise(12)}}> 1.0 </Text>
              </Text>

            <TouchableOpacity
              onPress={() => {
                setModalVisible(!modalVisible);
              }}
              style={{
                // marginStart: normalise(20),
                // marginEnd: normalise(20),
                marginBottom: normalise(20),
                height: normalise(40),
                // width: '95%',
                backgroundColor: Colors.fadeblack,
                opacity: 10,
                borderRadius: 6,
                // padding: 35,
                alignItems: 'center',
                justifyContent: 'center',
                marginTop: normalise(24),
              }}>
              <Text
                style={{
                  fontSize: normalise(12),
                  fontFamily: 'ProximaNova-Bold',
                  color: Colors.white,
                }}>
                CANCEL
              </Text>
            </TouchableOpacity>
          </View>
        </ImageBackground>
      </Modal>
    );
  };

  const policyModel = () => {
    return (
      <Modal
        animationType="fade"
        transparent={false}
        visible={modalPrivacy}
        presentationStyle={'pageSheet'}
        onRequestClose={() => {setModalPrivacy(false)}}>
       
<View style={{flex:1,backgroundColor:'#0D1E25'}}>
<View style={{marginTop:'5%' }}>
            <TouchableOpacity
              style={{ marginLeft: normalise(10) }}
              onPress={() => {
               setModalPrivacy(false)
              }}>
              <Image
                source={ImagePath.backicon}
                style={{ height: normalise(15), width: normalise(15) }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
<WebView
        source={{ uri: 'https://www.choona.co/privacy' }}
        // style={{ marginTop: 20 }}
      />
</View>

      </Modal>
    );
  };

  const tandcsModel = () => {
    return (
      <Modal
        animationType="fade"
        transparent={false}
        visible={modaltandcs}
        presentationStyle={'pageSheet'}
        onRequestClose={() => {setModaltandcs(false)}}>
       
<View style={{flex:1,backgroundColor:'#0D1E25'}}>
<View style={{marginTop:'5%' }}>
            <TouchableOpacity
              style={{ marginLeft: normalise(10) }}
              onPress={() => {
               setModaltandcs(false)
              }}>
              <Image
                source={ImagePath.backicon}
                style={{ height: normalise(15), width: normalise(15) }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
<WebView
        source={{ uri: 'https://www.choona.co/tandcs' }}
        // style={{ marginTop: 20 }}
      />
</View>

      </Modal>
    );
  };
  return (
    <View style={{ flex: 1, backgroundColor: Colors.black }}>
      <StatusBar backgroundColor={Colors.black} />

      <Loader visible={props.status === USER_PROFILE_REQUEST} />
      <Loader visible={props.status === COUNTRY_CODE_REQUEST} />
    
      <SafeAreaView style={{ flex: 1 }}>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            width: '90%',
            alignSelf: 'center',
            justifyContent: 'space-between',
          }}>
          <View style={{ marginTop: normalise(10) }}>
            <TouchableOpacity
              style={{ marginRight: normalise(10) }}
              onPress={() => {
                props.navigation.goBack();
              }}>
              <Image
                source={ImagePath.backicon}
                style={{ height: normalise(15), width: normalise(15) }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>

          <View
            style={{
              flexDirection: 'row',
              marginTop: normalise(10),
            }}>
            <TouchableOpacity
              style={{ marginRight: normalise(10) }}
              onPress={() => {
                props.navigation.navigate('EditProfile');
              }}>
              <Image
                source={ImagePath.settings}
                style={{ height: normalise(20), width: normalise(20) }}
                resizeMode="contain"
              />
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {
                setModalVisible(!modalVisible);
              }}>
              <Image
                source={ImagePath.iconmenu}
                style={{ height: normalise(20), width: normalise(20) }}
                resizeMode="contain"
              />
            </TouchableOpacity>
          </View>
        </View>

        <View
          style={{
            width: '90%',
            alignSelf: 'center',
            flexDirection: 'row',
            alignItems: 'center',
            marginTop: normalise(15),
          }}>
          <Image
            source={{
              uri:
                constants.profile_picture_base_url +
                props.userProfileResp.profile_image,
            }}
            style={{
              height: normalise(68),
              width: normalise(68),
              borderRadius: normalise(40),
            }}
          />

          <View
            style={{
              flexDirection: 'column',
              alignItems: 'flex-start',
              marginLeft: normalise(20),
            }}>
            <Text
              style={{
                color: Colors.white,
                fontSize: normalise(15),
                fontFamily: 'ProximaNova-Semibold',
              }}>
              {props.userProfileResp.full_name}
            </Text>

            <Text
              style={{
                // marginTop: normalise(2),
                color: Colors.darkgrey,
                fontSize: normalise(11),
                fontFamily: 'ProximaNova-Regular',
              }}>
              {props.userProfileResp.username}
            </Text>

            <Text
              style={{
                marginTop: normalise(1),
                color: Colors.darkgrey,
                fontSize: normalise(11),
                fontFamily: 'ProximaNova-Regular',
              }}>
              {props.userProfileResp.location}
              {/* {flag} */}
            </Text>

            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                marginTop: normalise(2),
              }}>
              <TouchableOpacity
                onPress={() => {
                  props.navigation.push('Following', { type: 'user', id: '' });
                }}>
                <Text
                  style={{
                    color: Colors.darkgrey,
                    fontSize: normalise(11),
                    fontFamily: 'ProximaNova-Regular',
                  }}>
                  <Text
                    style={{
                      color: Colors.white,
                      fontFamily: 'ProximaNova-Semibold',
                    }}>
                    {props.userProfileResp.following}
                  </Text>{' '}
                  Following
                </Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => {
                  props.navigation.push('Followers', { type: 'user', id: '' });
                }}>
                <Text
                  style={{
                    marginLeft: normalise(8),
                    color: Colors.darkgrey,
                    fontSize: normalise(11),
                    fontFamily: 'ProximaNova-Regular',
                  }}>
                  <Text
                    style={{
                      color: Colors.white,
                      fontFamily: 'ProximaNova-Regular',
                    }}>
                    {props.userProfileResp.follower}
                  </Text>{' '}
                  Followers
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <ImageBackground
          source={ImagePath.gradientbar}
          style={{
            width: '100%',
            height: normalise(50),
            marginTop: normalise(10),
          }}>
          {_.isEmpty(props.userProfileResp.feature_song) ? ( // IF DATA IS EMPTY
            <View
              style={{
                width: '90%',
                alignSelf: 'center',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                height: normalise(50),
              }}>
              <TouchableOpacity
                style={{
                  backgroundColor: Colors.fadeblack,
                  height: normalise(40),
                  width: normalise(40),
                  justifyContent: 'center',
                  alignItems: 'center',
                  // borderColor: Colors.white, borderWidth:1, borderRadius: normalise(5)
                }}
                onPress={() => {
                  props.navigation.navigate('FeaturedTrack');
                }}>
                <Image
                  source={ImagePath.addicon}
                  style={{
                    height: normalise(20),
                    width: normalise(20),
                    borderRadius: normalise(10),
                  }}
                />
              </TouchableOpacity>

              <View
                style={{
                  flexDirection: 'column',
                  alignItems: 'flex-start',
                  marginLeft: normalise(10),
                }}>
                <Text
                  style={{
                    color: Colors.white,
                    fontSize: normalise(9),
                    fontFamily: 'ProximaNova-Bold',
                    opacity: 0.5,
                  }}>
                  FEATURED TRACK
                </Text>

                <Text
                  style={{
                    width: '70%',
                    marginTop: normalise(1),
                    fontFamily: 'ProximaNova-Regular',
                    color: Colors.white,
                    fontSize: normalise(10),
                  }}>
                  You don't currently have a featured track. Let's add one
                </Text>
              </View>
            </View>
          ) : (
            // IF DATA IS NOT EMPTY
            <View
              style={{
                width: '90%',
                alignSelf: 'center',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                height: normalise(50),
              }}>
              <View style={{ flexDirection: 'row', alignItems: 'center' }}>
                <TouchableOpacity
                  onPress={() => {
                    props.navigation.navigate('Player', {
                      song_title: JSON.parse(
                        props.userProfileResp.feature_song,
                      )[0].song_name,
                      album_name: JSON.parse(
                        props.userProfileResp.feature_song,
                      )[0].album_name,
                      song_pic: JSON.parse(
                        props.userProfileResp.feature_song,
                      )[0].song_pic,
                      uri: JSON.parse(props.userProfileResp.feature_song)[0]
                        .song_uri,
                      artist: JSON.parse(props.userProfileResp.feature_song)[0]
                        .artist_name,
                      changePlayer: true,
                      originalUri: JSON.parse(
                        props.userProfileResp.feature_song,
                      )[0].hasOwnProperty('original_song_uri')
                        ? JSON.parse(props.userProfileResp.feature_song)[0]
                            .original_song_uri
                        : undefined,
                      registerType: props.userProfileResp.register_type,
                      isrc: JSON.parse(props.userProfileResp.feature_song)[0]
                        .isrc_code,
                    });
                  }}>
                  <Image
                    source={{
                      uri: JSON.parse(props.userProfileResp.feature_song)[0]
                        .song_pic,
                    }}
                    style={{ height: normalise(40), width: normalise(40) }}
                  />
                  <Image
                    source={ImagePath.play}
                    style={{
                      height: normalise(25),
                      width: normalise(25),
                      position: 'absolute',
                      marginLeft: normalise(8),
                      marginTop: normalise(8),
                    }}
                  />
                </TouchableOpacity>

                <View
                  style={{
                    marginStart: normalise(10),
                    width: '70%',
                  }}>
                  <Text
                    style={{
                      color: Colors.white,
                      fontSize: normalise(9),
                      fontFamily: 'ProximaNova-Regular',
                    }}>
                    FEATURED TRACK
                  </Text>

                  <Text
                    numberOfLines={1}
                    style={{
                      color: Colors.white,
                      fontSize: normalise(10),
                      fontFamily: 'ProximaNova-Bold',
                    }}>
                    {
                      JSON.parse(props.userProfileResp.feature_song)[0]
                        .song_name
                    }
                  </Text>

                  <Text
                    numberOfLines={1}
                    style={{
                      color: Colors.white,
                      fontSize: normalise(9),
                      fontFamily: 'ProximaNova-Regular',
                    }}>
                    {
                      JSON.parse(props.userProfileResp.feature_song)[0]
                        .album_name
                    }
                  </Text>
                </View>
              </View>

              <TouchableOpacity
                onPress={() => {
                  props.navigation.navigate('FeaturedTrack');
                }}>
                <Image
                  source={ImagePath.change}
                  style={{
                    height: normalise(40),
                    width: normalise(40),
                  }}
                />
              </TouchableOpacity>
            </View>
          )}
        </ImageBackground>

        {_.isEmpty(profilePosts) ? (
          <View
            style={{ flex: 1, alignItems: 'center' }}>
            {/* <View
              style={{
                height: '50%',
                justifyContent: 'flex-end',
                alignItems: 'center',
                width: '60%',
              }}> */}

<Image
              source={ImagePath.emptyPost}
              style={{
                height: 2*normalise(90),
                width: 2*normalise(90),
                 marginTop: '8%',
              }}
              resizeMode="contain"
            />
              <Text
                style={{
                  color: Colors.white,
                  fontSize: normalise(15),
                  // fontWeight: 'bold',
                  textAlign: 'center',
                  marginTop:'5%',
                  fontFamily: 'ProximaNova-Bold',
                }}>
                Your Profile is Empty
              </Text>

              <Text
                style={{
                  color: Colors.fordGray,
                  fontSize: normalise(12),
                  fontWeight: '100',
                  marginTop: normalise(7),
                  width: '65%',
                  textAlign: 'center',
                  alignSelf:'center',
                  fontFamily: 'ProximaNova-Regular',
                }}>
                You haven’t uploaded any songs to Choona yet, click the button below to add your first song.
              </Text>
            {/* </View> */}

            {/* <View
              style={{
                height: '50%',
                justifyContent: 'flex-end',
                alignItems: 'center',
                width: '80%',
              }}> */}
              <TouchableOpacity
                style={{
                  marginBottom: normalise(10),
                  height: normalise(48),
                  width: '80%',
                  alignItems: 'center',
                  justifyContent: 'center',
                  borderRadius: normalise(20),
                  backgroundColor: Colors.white,
                  position:'absolute',
                  bottom:8
                }}
                onPress={() => {
                  props.navigation.replace('bottomTab', { screen: 'Add' });
                }}>
                <Text
                  style={{
                    color: Colors.black,
                    fontSize: normalise(12),
                    fontWeight: 'bold',
                  }}>
                 ADD YOUR FIRST POST
                </Text>
              </TouchableOpacity>
            {/* </View> */}
          </View>
        ) : (
          <FlatList
            style={{ paddingTop: normalise(10) }}
            data={profilePosts}
            renderItem={renderProfileData}
            keyExtractor={(item, index) => {
              index.toString();
            }}
            showsVerticalScrollIndicator={false}
            numColumns={2}

            onEndReached={()=>
              onEndReached()
                
              }
               onEndReachedThreshold={1}

          />
        )}

        {renderModal()}
        {policyModel()}
        {tandcsModel()}
      </SafeAreaView>
    </View>
  );
}

const mapStateToProps = state => {
  return {
    status: state.UserReducer.status,
    userProfileResp: state.UserReducer.userProfileResp,
    countryCode: state.UserReducer.countryCodeOject,
    header: state.TokenReducer,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getProfileReq: () => {
      dispatch(getProfileRequest());
    },

    logoutReq: () => {
      dispatch(userLogoutReq());
    },

    getCountryCode: () => {
      dispatch(getCountryCodeRequest());
    },
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(Profile);

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end',
    alignItems: 'center',
  },
  modalView: {
    // marginBottom: normalise(10),
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    bottom: 0,
    left: 0,
    right: 0,
    position: 'absolute',
    backgroundColor: Colors.darkerblack,
    // margin: 20,
    padding: 20,
    paddingTop: normalise(24),
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  openButton: {
    backgroundColor: '#F194FF',
    borderRadius: 20,
    padding: 10,
    elevation: 2,
  },
  textStyle: {
    color: 'white',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  modalText: {
    marginBottom: 15,
  },
});
