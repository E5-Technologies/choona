const Colors = {
  black: '#1a1b1f',
  fadeblack: '#25262a',
  darkerblack: '#121317',
  white: '#ffffff',
  grey: '#767779',
  darkgrey: '#959698',
  blue: '##449C8C',
  red: '#e24f4f',
  facebookblue: '#3e63ab',
  grey_text: '#979797',
  activityBorderColor: '#25262A',
  emoji_board: '#EAEAEC',
  fordGray:'#979797'
};

export default Colors;
